#!/bin/bash

source repoconfig.sh

./start.sh "$DEV_REPO"

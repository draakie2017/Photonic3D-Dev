#!/bin/bash

source repoconfig.sh

./start.sh "$TESTKITDEV_REPO" "TestKit"

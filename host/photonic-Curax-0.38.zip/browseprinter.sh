#!/bin/bash

java -cp lib/*:. org.area515.resinprinter.client.Main &
#!/bin/bash

./start.sh "draakie2017/Photonic3D" force

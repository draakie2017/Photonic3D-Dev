#!/bin/bash

source repoconfig.sh

./start.sh "$TESTKIT_REPO" "TestKit"
